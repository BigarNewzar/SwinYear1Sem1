<?php
 
session_start();
if(isset($_SESSION["logCorrect"])){

     function sanitise_input($data){
		$data = trim($data);	//remove leading or trailing spaces
		$data = stripslashes($data);	//remove backslashes in front of quotes
		$data = htmlspecialchars($data);	//converts html control characters like < to html coce &lt;
		return $data;
	}
	
function checkStateToPostCode($state, $postcode) {
	$errMsg2 = "";
	switch ($state){
    case "VIC":
      if (!preg_match("/^[38]\d{3}$/",$postcode)) {//start with 3 or 8 as a single digit, then 3 random digit
        $errMsg2 .= "VIC must start postcode with 3 or 8 \n";
      }
      break;
	case "NSW":
      if (!preg_match("/^[12]\d{3}$/",$postcode)) {//start with 1 or 2 as a single digit, then 3 random digit
        $errMsg2 .= "NSW must start postcode with 1 or 2 \n";
      }
      break;
	case "QLD":
      if (!preg_match("/^[49]\d{3}$/",$postcode)) {//start with 4 or 9 as a single digit, then 3 random digit
        $errMsg2 .= "QLD must start postcode with 4 or 9 \n";
      }
      break;
	case "NT":
      if (!preg_match("/^0\d{3}$/",$postcode)) {//start with 0 as a single digit, then 3 random digit
        $errMsg2 .= "NT must start postcode with 0 \n";
      }
      break;
	case "WA":
      if (!preg_match("/^6\d{3}$/",$postcode)) {//start with 6 as a single digit, then 3 random digit
        $errMsg2 .= "WA must start postcode with 6 \n";
      }
      break;
	case "SA":
      if (!preg_match("/^5\d{3}$/",$postcode)) {//start with 5 as a single digit, then 3 random digit
        $errMsg2 .= "SA must start postcode with 5 \n";
      }
      break; 
	case "TAS":
      if (!preg_match("/^7\d{3}$/",$postcode)) {//start with 7 as a single digit, then 3 random digit
        $errMsg2 .= "TAS must start postcode with 7 \n";
      }
      break; 
	case "ACT":
      if (!preg_match("/^0\d{3}$/",$postcode)) {//start with 0 as a single digit, then 3 random digit
        $errMsg2 .= "ACT must start postcode with 0 \n";
      }
      break; 
	}
	return $errMsg2;
	}
	
	
function checkCreditTypeWithNumber($card_type, $card_number) {
   $errMsg3 = "";
  switch ($card_type) {
	case "Visa":
      if (!preg_match("/^4\d{15}$/",$card_number)) {//start with 4, then 15 random digits
        $errMsg3 .= "Visa Card must start with 4 and be 16 digits long \n";
      }

      break;
    case "Mastercard":
      if (!preg_match("/^5[1-5]\d{14}$/",$card_number)) {//start with 5, then 1-5 any single digit, then 14 rest random digit
        $errMsg3 .= "Mastercard must start with digits 51 to 55 and be 16 digits long\n";
      }

      break;
    case "American_Express":
      if (!preg_match("/^3[47]\d{13}$/",$card_number)) {//start with 3, then 4 or 7 any specific digit, then 13 rest any random digit
        $errMsg3 .= "American Express must start with digits 34 or 37 and be 15 digits long \n";
      }

      break;
    
  }
  return $errMsg3;

}
	function calcCost($quantity, $features, $product){
	$cost1 = 0;
	if ($product=="Stark") $cost1 = 10000;
	if ($product=="Vibranium") $cost1 = 12000;
	if ($product=="PUBGMania") $cost1 = 8000;
	
	
	if ($features=="wired,") $cost1 += 300;
	if ($features=="wired, bluetooth,") $cost1 += 800;
	if ($features=="wired, bluetooth, wifi") $cost1 += 1400;
	if ($features=="bluetooth,") $cost1 += 500;
	if ($features=="bluetooth, wifi") $cost1 += 1100;
	if ($features=="wifi") $cost1 += 600;
	if ($features=="wired, wifi") $cost1 += 900;
	$cost1 = $cost1 * $quantity;
	
	return $cost1;
}

	if(isset($_POST["firstname"]))	$firstname = sanitise_input($_POST["firstname"]);	
	if(isset($_POST["lastname"]))	$lastname = sanitise_input($_POST["lastname"]);
	if(isset($_POST["email"]))	$email = sanitise_input($_POST["email"]);
	if(isset($_POST["streetAddress"]))	$street_address = sanitise_input($_POST["streetAddress"]);
	if(isset($_POST["suburb"]))	$suburb = sanitise_input($_POST["suburb"]);
	
	
	
	if(isset($_POST["stateText"])){	
		$state = sanitise_input($_POST["stateText"]);
	}
	
	
	
	
	if(isset($_POST["postCode"]))	$postcode = sanitise_input($_POST["postCode"]);
	if(isset($_POST["phoneNumber"]))	$phone_number = sanitise_input($_POST["phoneNumber"]);
	
	if(isset($_POST["contact"])){	
		$contact = sanitise_input($_POST["contact"]);
	}
	
	if(isset($_POST["productText"]))	{
		$product = sanitise_input($_POST["productText"]);}
	
	if(isset($_POST["speaker"]))		$features = sanitise_input($_POST["speaker"]);
	
	if( isset($_POST["wired"])  ||  isset($_POST["bluetooth"])  ||  isset($_POST["wifi"])  ){
		$features = "";
		if(isset($_POST["wired"]))
			$features = $features. sanitise_input($_POST["wired"]). ",";
		if(isset($_POST["bluetooth"]))
			if( $features=="")
			   $features = $features. sanitise_input($_POST["bluetooth"]). ",";
		    else
			   $features = $features. " ".sanitise_input($_POST["bluetooth"]). ",";
		if(isset($_POST["wifi"]))
			if( $features=="")
			   $features = $features. sanitise_input($_POST["wifi"]);
		    else
			   $features = $features. " ".sanitise_input($_POST["wifi"]);
	}
	
	if(isset($_POST["quantity"]))		$quantity = sanitise_input($_POST["quantity"]);
	
	if(isset($_POST["comment"]))		$comment = sanitise_input($_POST["comment"]);


	if(isset($_POST["pCT"]))	{
		$card_type = sanitise_input($_POST["pCT"]);}
	else{
		$card_type ="Unknown card type";
	}

	if(isset($_POST["pCna"]))		$card_name = sanitise_input($_POST["pCna"]);
	if(isset($_POST["pCnu"]))		$card_number = sanitise_input($_POST["pCnu"]);
	if(isset($_POST["pEdate"]))		$card_expiry_date = sanitise_input($_POST["pEdate"]);
	
	if(isset($_POST["pCVV"]))		$card_verification_value = sanitise_input($_POST["pCVV"]);
	
	
		
	$errMsg = "";
	
	if ($firstname==""){
		$errMsg = $errMsg . "You must enter your first name.";
	}
	else if (!preg_match("/^[a-zA-Z]{1,25}$/", $firstname)){
		$errMsg = $errMsg . "Your first name must only contain 25 alpha characters\n";
	}
	if ($lastname==""){
		$errMsg = $errMsg . "You must enter your last name.";
	}
	else if (!preg_match("/^[a-zA-Z]{1,25}$/", $lastname)){
		$errMsg = $errMsg . "Your last name must only contain 25 alpha characters\n";
	}
	if ($email==""){
		$errMsg = $errMsg . "You must enter your email.";
	}
	else if (!preg_match("/^.+@.+\..{2,3}$/", $email)){//taken from lect02 regular expression, common expression list, (eg victor41@google.com)
		$errMsg = $errMsg . "Please give a valid email address\n";
	}
	
	if ($street_address==""){
		$errMsg = $errMsg . "You must enter your street address.";
	}
	else if (!preg_match("/^[a-zA-Z0-9 ]{1,40}$/", $street_address)){
		$errMsg = $errMsg . "Your street address must only contain 40 alphanumeric characters with space\n";
	}
	
	if ($suburb==""){
		$errMsg = $errMsg . "You must enter your suburb.";
	}
	else if (!preg_match("/^[a-zA-Z0-9 ]{1,20}$/", $suburb)){
		$errMsg = $errMsg ."Your suburb must only contain 20 alphanumeric characters with space. \n";
	}
	
	
	if ($state=="Please Select"){
		$errMsg = $errMsg . "Please Enter a state";
	}
	else{
		$tempAMsg = checkStateToPostCode($state, $postcode);
		if ($tempAMsg != "") {
      $errMsg = $errMsg . $tempAMsg;
      
		}
	}
	
	if ($postcode==""){
		$errMsg = $errMsg . "You must enter your postcode.";
	}
	else if (!preg_match("/^\d{4}$/", $postcode)){//only 4 digits
		$errMsg = $errMsg ."Your post code must only contain 4 digits\n";
	}
	
	if ($phone_number==""){
		$errMsg = $errMsg . "You must enter your phone number.";
	}
	else if (!preg_match("/^\d{10}$/", $phone_number)){//only 10 digits
		$errMsg = $errMsg ."Your phone number must only contain 10 digits\n";
	}
	
	
	
	
	//may need to change this
	if($contact==""){
		$errMsg = $errMsg . "Please select at least one preferred Contact. \n";
	}
	//may need to change this
	if ($product=="Please Select"){
		$errMsg = $errMsg . "Please select at least one product. \n";
	}
	//may need to change this
	if($features==""){
		$errMsg = $errMsg . "Please select at least one feature. \n";
	}
	
	
	if (!is_numeric($quantity)){//quantity must be a number
		$errMsg = $errMsg ."Your quantity must be a number\n";
	}
	else if ($quantity < 0 || $quantity > 10000){
		$errMsg = $errMsg ."Your quantity must be between 0 and 10,000\n";
	}
	//no validation given previously for comment so skipped it
	
	//it didnt detect this
	if ($card_type==""){
		$errMsg = $errMsg . "Credit Card must be of Visa, Mastercard, or American Express. \n";
	}
	
	
	
	if ($card_name==""){
		$errMsg = $errMsg . "You must enter your name on credit card.";
	}
	else if (!preg_match("/^[a-zA-Z ]{1,40}$/", $card_name)){
		$errMsg = $errMsg . "Your name on credit card must only contain 40 alpha characters with space\n";
	}
	
	if ($card_number==""){
		$errMsg = $errMsg . "You must enter your credit card number.";
	}
	else if (!preg_match("/^[0-9]{15,16}$/", $card_number)){
		$errMsg = $errMsg . "Your credit card number must be between 15 to 16 digits\n";
	}
	/*check card type with card number*/
	/*didnt put it in "else" as i wanted it to check the card type with card number simultaneously while running the previous card number restriction*/
	$tempAMsg2 = checkCreditTypeWithNumber($card_type, $card_number);
  if ($tempAMsg2 != "") {
    $errMsg = $errMsg . $tempAMsg2;
    
  }
	
	
	if ($card_expiry_date==""){
		$errMsg = $errMsg . "You must enter credit card Expiry Date.";
	}
	
	//Warning: preg_match(): Null byte in regex in /home/students/accounts/s103172423/cos10011/www/htdocs/testing/process_order.php on line 258
//how to solve this and give mm-yy format for date?	
	else if (!preg_match("/^(0[1-9]|1[012])-([0-9]{2})$/", $card_expiry_date)){//0[1-9]|1[012] restricting data from 01 to 12 for month and restrict year to 2 digit
		$errMsg = $errMsg . "Expiry date must be in mm-yy format\n";
	}
	
	if (!is_numeric($card_verification_value)){//CVV must be a number
		$errMsg = $errMsg ."Your CVV must be a number\n";
	}
	else if (!preg_match("/^\d{3}$/", $card_verification_value)){
		$errMsg = $errMsg . "CVV is only 3 digits long!\n";
	}
	
	$cost	=	calcCost($quantity, $features, $product);
	
	
	if($errMsg !=""){
		
		header("location:fix_order.php"); // directly directs to the fix_order.php which is a form version of the payment with enterable stuff.
		
				//start the session
	if (!isset ($_SESSION["number"])){	//check if session variable exists
		$_SESSION["number"] = 0;		//create and set the session variable
	}
			 $_SESSION["firstname"]= $firstname;
			$_SESSION["lastname"]= $lastname;
		$_SESSION["email"]= $email;
		$_SESSION["street_address"]= $street_address;
		$_SESSION["suburb"]= $suburb;
		$_SESSION["state"]= $state;
		$_SESSION["postcode"]= $postcode;
		$_SESSION["phone_number"]= $phone_number;
		$_SESSION["contact"]= $contact;
		$_SESSION["product"]= $product;
		$_SESSION["features"]= $features;
		$_SESSION["quantity"]= $quantity;
		$_SESSION["comment"]= $comment;

		$_SESSION["ctype"]= $card_type;
		$_SESSION["cname"]= $card_name;
		$_SESSION["cnumber"]= $card_number;
		$_SESSION["cexpiry"]= $card_expiry_date;
		$_SESSION["cCVV"]= $card_verification_value;
		$_SESSION["cost"]= $cost;


//credit card details will be reentered in the new page
		
		
	}
	else{
		
		
		//change this into calculate store and other stuff later
		
	
	require_once ("settings.php");	//connection info
	
	$conn = @mysqli_connect(	$host,
								$user,
								$pwd,
								$sql_db
							);
	//checks if connection is successful
	if(!$conn){
		//displays an error message
		echo "<p>Database Connection failure</p>";	//not in production script
	}
	else  {
		//upon successful connection
		//https://stackoverflow.com/questions/167576/check-if-table-exists-in-sql-server
		//https://stackoverflow.com/questions/5952006/check-if-table-exists-and-if-it-doesnt-exist-create-it-in-sql-server-2008
		//using "if exists" form the 2 links above to check if table exists or not before taking further steps
		
		//the website's technique didnt work. 
		//So using the alternative way suggested by tutor Bo, 
		//and placing it inside a query instead of calling it via "if" function 
		 
			$query2= "CREATE TABLE IF NOT EXISTS orders(
				order_id INT(11) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
				order_cost FLOAT NOT NULL ,
				order_time TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ,
				order_status SET('Pending','Fulfilled','Paid','Archived') NOT NULL DEFAULT 'PENDING' ,
				firstname VARCHAR(25) NOT NULL,
				lastname VARCHAR(25) NOT NULL,
				email VARCHAR(40) NOT NULL,
				street_address VARCHAR(40) NOT NULL,
				suburb VARCHAR(20) NOT NULL,
				state VARCHAR(3) NOT NULL,
				post_code INT(4) NOT NULL,
				phone_number INT(10) NOT NULL,
				contact VARCHAR(5) NOT NULL,
				product_name VARCHAR(10) NOT NULL,
				speaker VARCHAR(30) NOT NULL,
				quantity INT(4) NOT NULL,
				comment VARCHAR(256) NOT NULL,
				card_type VARCHAR(16) NOT NULL,
				card_name VARCHAR(40) NOT NULL,
				card_number INT(16) NOT NULL,
				card_expiration_date VARCHAR(5) NOT NULL,
				card_verification_value INT(3) NOT NULL
			
			
			)";
		  
		 mysqli_query($conn, $query2);
		$sql_table="orders";
		
		//set up the SQL command to query or add data into the table
		$query = "INSERT INTO $sql_table(order_cost, firstname, lastname, email, street_address, suburb, state, post_code, phone_number, contact, product_name, speaker, quantity, comment, card_type, card_name, card_number, card_expiration_date, card_verification_value) VALUES ($cost, '$firstname', '$lastname', '$email', '$street_address', '$suburb', '$state', $postcode, $phone_number, '$contact', '$product', '$features', $quantity, '$comment', '$card_type', '$card_name', $card_number, '$card_expiry_date', $card_verification_value)";
		
		//execute the query -we should really check if the database exists first.
		$result = mysqli_query($conn, $query);
		
		//checks if the execution was successful
		if (!$result) {
			echo "<p> Something is wrong with ", $query, "</p>";
			//would not show in a production script
		}
		else {
			//display an operation successful message
			header("location:receipt.php"); // directly directs to the receipt.php which returns with all the records stored in orders table in it.
		
		//if successful query operation
		
		//close the database connection
		mysqli_close($conn);
		}//if successful database connection
	}	
	if (!isset ($_SESSION["number"])){	//check if session variable exists
		$_SESSION["number"] = 0;		//create and set the session variable
	}
			 $_SESSION["firstname"]= $firstname;
			$_SESSION["lastname"]= $lastname;
		$_SESSION["email"]= $email;
		$_SESSION["street_address"]= $street_address;
		$_SESSION["suburb"]= $suburb;
		$_SESSION["state"]= $state;
		$_SESSION["postcode"]= $postcode;
		$_SESSION["phone_number"]= $phone_number;
		$_SESSION["contact"]= $contact;
		$_SESSION["product"]= $product;
		$_SESSION["features"]= $features;
		$_SESSION["quantity"]= $quantity;
		$_SESSION["comment"]= $comment;

		$_SESSION["ctype"]= $card_type;
		$_SESSION["cname"]= $card_name;
		$_SESSION["cnumber"]= $card_number;
		$_SESSION["cexpiry"]= $card_expiry_date;
		$_SESSION["cCVV"]= $card_verification_value;
		$_SESSION["cost"]= $cost;
	
		
		
	}



}

else{

     echo "You cannot access this page directly";

}
?>	