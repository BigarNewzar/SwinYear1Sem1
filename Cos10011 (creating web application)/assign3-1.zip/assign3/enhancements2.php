<!DOCTYPE html>
<?php
	include_once("header.inc");
?>


<body>

<?php
	include_once("menu.inc");
?>



<aside id="right"> <!--put advert here to right of page-->
<figure>

	<a href="https://www.primevideo.com/region/eu" >
		<img class="img" src="images/stream.png" alt="amazon stream advert"/>
	</a>

	<p>
		<a href="  https://www.pinterest.com/pin/561964859746504753/"> pic reference </a>
	</p>
<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

</figure>
</aside>


<article>
<section class= "into_stuff"	>
<h1>The enhancements I made using Javascript:</h1>
<ol>

<li><p>I have added a countdown timer on payment webpage</p>

<ol>
	<li><p>
	It triggers on auto whenever the page loads(line by line details of how the code works is given in the comments in the javaScript file) and programmer only needs to link webpage to the javaScript file and also the link the object that will contain the countdown timer.
	<br> Once countdown reaches to zero, it will give a warning and redirect user back to homepage.</p>
	<p>This will create a sense of urgency and persuade the user to immediately enter and submit the data, instead of delaying. Thus they will be more careful and will give more importance in filling up their credit card information properly and quickly.</p>
	</li>

<li>
<p><a href="payment.php">I have used it here in payment webpage</a></p>
</li>

<li>
<p>
I had found out about the code from the website: </p>
<p>
<a href="https://codepen.io/rxsharp/pen/jPZgpX">
    https://codepen.io/rxsharp/pen/jPZgpX</a></p>
</li>

<li>
<p>
 It has not been mentioned at all in the assignment requirements or the lecture and tutorials of this course and hence i believe it to go beyond the basic requirements of this assignment.
</p>
 </li>
 
 </ol>
 
</li>

<li>
  <p>Preloaded Name on credit card as concatenation of firstname and lastname</p>
	

<ol>
<li><p>
It triggers on auto whenever the page loads (details of how the code works is given in the comments in the javaScript file) and programmer only needs to link webpage to the javaScript file and also the link the object that will contain the current date function.</p>
<p> This will automatically concatenate the stored first and last name into that of credit card as well as default. But user can change the value as it is in an input field here!</p>

</li>


<li>
<p><a href="payment.php">I have used it here in payment webpage</a></p>
</li>

<li>
<p>
Took idea from these two websites: </p>
<p>
<a href="https://www.w3schools.com/html/html_form_attributes.asp">
   https://www.w3schools.com/html/html_form_attributes.asp</a></p>
 <p>
<a href="https://www.w3schools.com/jsref/prop_win_sessionstorage.asp">
   https://www.w3schools.com/jsref/prop_win_sessionstorage.asp</a></p>
   
</li>

<li>
<p>
 It has has been suggested as an example of javaScript enhancement in the page and hence i believe it to go beyond the basic requirements of this assignment.
</p>
</li>
  
  
  
 
 
  </ol>
	</li>
	</ol>
</section>
</article>




<?php
	include_once("footer.inc");
?>
</body>
</html>	