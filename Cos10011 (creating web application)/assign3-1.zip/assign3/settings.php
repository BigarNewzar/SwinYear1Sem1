<?php
	$host = "feenix-mariadb.swin.edu.au";
	$user = "s103172423"; // your user name
	$pwd = "221200"; // your password (date of birth ddmmyy unless changed)
	$sql_db = "s103172423_db"; // your database
	
	
?>
	
	
	