<?php
session_start();	//start the session
	if(		$_SESSION["sort"]=="" || $_SESSION["sort"]=="revsort"){
		$_SESSION["sort"]="sort";
		
	}
	else{
		$_SESSION["sort"]="revsort";
	}	
	
	
	header("location:manager.php")

?>
