<!DOCTYPE html>
<html lang="en">
<?php
	include_once("header.inc");
?>


<body>

<?php
	include_once("menu.inc");
?>



<aside id="right"> <!--put advert here to right of page-->
<figure>

	<a href="https://www.primevideo.com/region/eu" >
		<img class="img" src="images/stream.png" alt="amazon stream advert"/>
	</a>

	<p>
		<a href="  https://www.pinterest.com/pin/561964859746504753/"> pic reference </a>
	</p>
<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

</figure>
</aside>


<article>
<section class= "into_stuff"	>
<h1>The enhancements I made in the Html pages:</h1>
<ol>
<li><p>I have added 2 videoes on the webpage, </p>
<ol><li>
Showing details about tv. This is mainly to let customers know more about television statistics in general and make them better equipped to make decisions regarding which tv to purchase.
</li>
<li>
Giving them a tour through my hometown, sylhet, in first person view, to let them experience how magnificent the place really is.
</li>
</ol>

 <p>This feature has been implimented using the code:</p>
 
<figure>
<figcaption>
<a href="index.php#Tv_Champ">I have used it here in Index</a></figcaption>
<img class="img" src="images/ss1.1.png" alt="code for tv video"/>
</figure>

<figure>
<figcaption><a href="about.php#sylhet">I have used it here in About</a></figcaption>
<img class="img" src="images/ss1.2.png" alt="code for sylhet video"/>
</figure>


<p>
I had found out about the code from the website: </p>
<p>
<a href=" https://www.w3schools.com/html/html5_video.asp">
     https://www.w3schools.com/html/html5_video.asp</a></p>

<p>
 It has not been mentioned at all in the assignment requirements or the lecture and tutorials of this course and hence i believe it to go beyond the basic requirements of this assignment.
</p>

 </li>
 
<li><p>Gave a suitable audio file to play on the background of each page and also let the reader choose whether to play it or not and also choose the volume. This gives the user more control of what they want to recieve from the website and hence increase user favorability. <br/>
Furthermore, since its looped, once permitted, it will continue to play until stopped by user. Hence user dont have to restart it again and again </p>

 <p>This feature has been implimented using the code:</p>
 
<figure>
<figcaption>Used it in <a href="index.php#A1">Index</a>, <a href="product.php#A2">product</a>, <a href="enquire.php#A3">enquire</a>, <a href="about.php#A4">about</a> webpages.<br/> (scroll above the music reference line.)
</figcaption>
<img class="img" src="images/ss2.png" alt="code for audio"/>
</figure>

<p>
I had found out about the code from the website: </p>
<p>
<a href=" https://www.w3schools.com/html/html5_video.asp">
     https://www.w3schools.com/html/html5_video.asp</a></p>

<p>
 It has not been mentioned at all in the assignment requirements or the lecture and tutorials of this course and hence i believe it to go beyond the basic requirements of this assignment.
</p></li>
</ol>
<p>NB: There were more changes that I had added to each webpage to further enhance the design and layout (like hover, background image fixed, navigation bar fixed, footer fixed, etc). But compared to these two, their effects seemed trivial. Hence I am not mentioning them here.</p>
</section>
</article>





<?php
	include_once("footer.inc");
?>
</body>
</html>	