<?php
session_start();
if(isset($_SESSION["logCorrect"])){
		if (!isset ($_SESSION["number"])){	//check if session variable exists
				$_SESSION["number"] = 0;		//create and set the session variable
			}
			$firstname = $_SESSION["firstname"];
			$lastname = $_SESSION["lastname"];
			$email = $_SESSION["email"];
			$street_address = $_SESSION["street_address"];
			$suburb = $_SESSION["suburb"];
			$state = $_SESSION["state"];
			$postcode = $_SESSION["postcode"];
			$phone_number = $_SESSION["phone_number"];
			$contact = $_SESSION["contact"];
			$product = $_SESSION["product"];
			$features = $_SESSION["features"];
			$quantity = $_SESSION["quantity"];
			$comment = $_SESSION["comment"];
			
			
			$card_type = $_SESSION["ctype"];
			$card_name = $_SESSION["cname"];
			$card_number = $_SESSION["cnumber"];
			$card_expiry_date = $_SESSION["cexpiry"];
			$card_verification_value = $_SESSION["cCVV"];
			$cost = $_SESSION["cost"];
     // continue to do the other options
echo"<!DOCTYPE html>
<html lang='en'>";

	include_once("header.inc");


echo"
<body>";


	include_once("menu.inc");
	
	
	require_once ("settings.php");	//connection info
	
	$conn = @mysqli_connect(	$host,
								$user,
								$pwd,
								$sql_db
							);
	//checks if connection is successful
	if(!$conn){
		//displays an error message
		echo "<p>Database Connection failure</p>";	//not in production script
	}
	else  {
		//upon successful connection
		
		$sql_table="orders";
		
		//set up the SQL command to query or add data into the table
		$query = "SELECT * FROM $sql_table order by order_id desc limit 1";
		
		//execute the query and store result into the result pointer
		$result = mysqli_query($conn, $query);
		
		//checks if the execution was successful
		if (!$result) {
			echo "<p>Something is wrong with ", $query, "</p>";
		}
		else {
			//display the retrieved records
			echo "<table border=\"1\">\n";
			echo "<tr>\n"
				."<th scope=\"col\">Order ID</th>\n "
				."<th scope=\"col\">Order Cost</th>\n "
				."<th scope=\"col\">Order Time</th>\n "
				."<th scope=\"col\">Order Status</th>\n "
				."<th scope=\"col\">Firstname</th>\n "
				."<th scope=\"col\">Lastname</th>\n "
				."<th scope=\"col\">Email</th>\n "
				."<th scope=\"col\">Street Address</th>\n "
				."<th scope=\"col\">Suburb</th>\n "
				."<th scope=\"col\">State</th>\n "
				."<th scope=\"col\">Postcode</th>\n "
				."<th scope=\"col\">Phone number</th>\n "
				."<th scope=\"col\">Contact</th>\n "
				."<th scope=\"col\">Product Name</th>\n "
				."<th scope=\"col\">Speaker</th>\n "
				."<th scope=\"col\">Quantity</th>\n "
				."<th scope=\"col\">Comment</th>\n "
				."<th scope=\"col\">Card Type</th>\n "
				."<th scope=\"col\">Card Name</th>\n "
				."<th scope=\"col\">Card Number</th>\n "
				."<th scope=\"col\">Card Expiration Date</th>\n "
				."<th scope=\"col\">Card Verification Value(cvv)</th>\n "
				."</tr>\n ";
				//the "\n" is optional. Creates tidy served code.
				
			//retieve current record pointed by the result pointer
			
			while ($row = mysqli_fetch_assoc($result)){
				echo "<tr>\n ";
				echo "<td>", $row["order_id"], "</td>\n ";
				echo "<td>", $row["order_cost"], "</td>\n ";
				echo "<td>", $row["order_time"], "</td>\n ";
				echo "<td>", $row["order_status"], "</td>\n ";
				echo "<td>", $row["firstname"], "</td>\n ";
				echo "<td>", $row["lastname"], "</td>\n ";
				echo "<td>", $row["email"], "</td>\n ";
				echo "<td>", $row["street_address"], "</td>\n ";
				echo "<td>", $row["suburb"], "</td>\n ";
				echo "<td>", $row["state"], "</td>\n ";
				echo "<td>", $row["post_code"], "</td>\n ";
				echo "<td>", $row["phone_number"], "</td>\n ";
				echo "<td>", $row["contact"], "</td>\n ";
				echo "<td>", $row["product_name"], "</td>\n ";
				echo "<td>", $row["speaker"], "</td>\n ";
				echo "<td>", $row["quantity"], "</td>\n ";
				echo "<td>", $row["comment"], "</td>\n ";
				echo "<td> ***** </td>\n ";
				echo "<td> *********</td>\n ";
				echo "<td> *************</td>\n ";
				echo "<td> *****</td>\n ";
				echo "<td> ***</td>\n ";
				echo "</tr>\n ";
			}
			echo "</table>\n ";
			
			//Frees up the memory, after using the result pointer
			mysqli_free_result($result);
		}//if successful query operation
		
		//close the database connection
		mysqli_close($conn);
	}//if successful database connection

echo"
</section>


</article>";




	include_once("footer.inc");

echo"
</body>
</html>";	

//commenting this part out following tutor bo' instruction
//session_destroy();

}

else{

     echo "You cannot access this page directly";

}
?>
