<!DOCTYPE html>
<?php
	include_once("header.inc");
?>


<body>

<?php
	include_once("menu.inc");
?>



<aside id="right"> <!--put advert here to right of page-->
<figure>

	<a href="https://www.primevideo.com/region/eu" >
		<img class="img" src="images/stream.png" alt="amazon stream advert"/>
	</a>

	<p>
		<a href="  https://www.pinterest.com/pin/561964859746504753/"> pic reference </a>
	</p>
<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

</figure>
</aside>


<article>
<section class= "into_stuff"	>
<h1>The enhancements I made using PHP:</h1>
<ol>

<li><p>I have added an advanced Manager report based on compound queries (fulfilled orders purchased between two dates entered)</p>

<ol>
	<li><p>
	Once cliked on the link, it will load up a form on the manager page, allowing the user to input two date in a given format (hint given using placeholders).
	<br> Once user presses submit, it will run a query looking for order status = fulfilled and dates between the given range</p>
	
	</li>

<li>
<p><a href="manager.php#enhance1">I have used it here in manager webpage</a></p>
</li>

<li><p>It lets the manager instantly find the number of fulfilled purchases made in a certain day range (eg from "2021-5-10 to 2021-5-20", "2021-6-5 to 2021-6-24", etc.) instead of just looking though the entire list.
</p>

<p>In both lectures and labs, we have never dealt with how to compare data given using type "timestamp" and type "set". Hence, it is beyond that which is taught and also is mentioned as an example in enhancement page. Hence, i believe it goes beyond the specified basic requirements of this assignment.
</p>
 </li>
 <li>

<p>In order to implement this, you need to give a query for select with conditions for "order_time" and "order_status". Also you need to input data using form and pass data to the query using $_POST["name"] (where name is the name inside the input tag given in the form and post is the form method). 
</p>
 </li>
 <li>

<p>I have done this al by myself by testing and retyping the query several times on the database's SQL tab until it finally gave me my desired output. 
</p>
 </li>
 </ol>
 
</li>

<li>
  <p>On "display all order" table in manager page, i have provided the ability to select a column heading "firstname" and sort the table in order of "firstname" and when clicked again, it reverses the order</p>
	

<ol>
<li><p>
Once clicked, it sorts the table of "display all orders" with respect to firstname and when reselected, it lets him or her sort it in reverse. </p>
</li>

<li>
<p><a href="manager.php#enhance2">I have used it here in manager webpage</a></p>
</li>
<li>
<p>
This enhancement provides more convenience to manager and makes it easier for him to go through the entire list at a glance.
</p>
<p> While the ability to sort a query has been mentioned, we have never learnt how to sort it in reverse and also how to make a query sort itself (when clicked on an heading) and to reverse sort when clicked again. Moreover it is mentioned as an example in enhancement page. Hence, i believe it goes beyond the specified basic requirements of this assignment.</p>
</li>
<li>

<p> Here you need to use a php file that will change "sort" into "rev" sort and vise versa(if nothing has been inputted, i.e. the manager clicked on link for 1st time, then automatically make it "sort"). Then in the manager file you need to add a variable to recieve the value and if it receieves "sort", it adds "order by asc" to query, and if it receieves "revsort", it adds "order by desc" to query (if it receives nothing, i.e the manager stil didnt click firstname, then no order command will be given to the query).</p>
</li>
<li>
<p>
I have taken the idea for descending order sort from this website: </p>
<p>
<a href="https://www.w3schools.com/sql/sql_ref_order_by.asp">
   https://www.w3schools.com/sql/sql_ref_order_by.asp</a></p>
 
   
</li>


  
  
  
 
 
  </ol>
	</li>
	</ol>

</section>
</article>




<?php
	include_once("footer.inc");
?>
</body>
</html>	