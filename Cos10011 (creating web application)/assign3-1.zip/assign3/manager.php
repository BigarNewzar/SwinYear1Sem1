<?php
	session_start();		//start the session
	if (!isset ($_SESSION["object"])){	//check if session variable exists
		$_SESSION["object"] = "object";		//create and set the session variable
	}
	$object = $_SESSION["object"];		//copy the value to a variable
	
	if (!isset ($_POST["status"])){	//check if session variable exists
		$_POST["status"]="";		//create and set the session variable
	}
	if (!isset ($_POST["order_id_delete"])){	//check if session variable exists
		$_POST["order_id_delete"]="";		//create and set the session variable
	}
	if (!isset ($_SESSION["sort"])){	//check if session variable exists
		$_SESSION["sort"]="";		//create and set the session variable
		
	}
		$sort = $_SESSION["sort"];		//create and set the session variable
		
?>
<!DOCTYPE html>
<html lang="en">
<?php
	include_once("header.inc");
?>


<body>

<?php
	include_once("menu.inc");
?>





<aside id="right"> <!--put advert here to right of page-->
<figure>

	<a href="https://www.primevideo.com/region/eu" >
		<img class="img" src="images/stream.png" alt="amazon stream advert"/>
	</a>

	<p>
		<a href="  https://www.pinterest.com/pin/561964859746504753/"> pic reference </a>
	</p>
<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

</figure>
</aside>

<article>
	<h1 id="bring_down">
		Which query do you want to make?
	</h1>
	
<section>	
	<p id="enhance2"><a href="orderdisplay.php">Display All Orders</a></p>	<!--links to updating pages-->
	<?php
	
	
	if($object == "allorder"){
		if ($_POST["status"] !=""){
					$status	= trim($_POST["status"]);
					$order_id = trim($_POST["order_id"]);
					
					if (!$status==""){
						require_once ("settings.php");	//connection info
					
						$connect = @mysqli_connect(	$host,
										$user,
										$pwd,
										$sql_db
									);
						//checks if connection is successful
						if(!$connect){
							//displays an error message
							echo "<p>Database Connection failure</p>";	//not in production script
						}
						else  {
							//upon successful connection
							
							$sql_tablename="orders";
							 $current_id  = $order_id;


							//set up the SQL command to query or add data into the table
							$queryupdate = "UPDATE $sql_tablename  SET order_status='$status'  where order_id= $current_id ";
							
							//execute the query and store result into the result pointer
							$resultupdate = mysqli_query($connect, $queryupdate);
							
							//checks if the execution was successful
							if (!$resultupdate) {
								echo "<p>Something is wrong with ", $queryupdate, "</p>";
							}
							
							//close the database connection
							mysqli_close($connect);
						}//if successful database connection

						}
					
								
		}	
							if(($_POST["order_id_delete"] !="")){
							
								require_once ("settings.php");	//connection info
				
								$connectagain = @mysqli_connect(	$host,
												$user,
												$pwd,
												$sql_db
											);
								//checks if connection is successful
								if(!$connectagain){
									//displays an error message
									echo "<p>Database Connection failure</p>";	//not in production script
								}
								else  {
									//upon successful connection
									
									$sql_tablenm="orders";
									 $current_id  = $_POST["order_id_delete"];
									 


									//set up the SQL command to query or add data into the table
									$queryupdate = "DELETE FROM $sql_tablenm  where order_id= $current_id ";
									
									//execute the query and store result into the result pointer
									$resultupdate = mysqli_query($connectagain, $queryupdate);
									
									//checks if the execution was successful
									if (!$resultupdate) {
										echo "<p>Something is wrong with ", $queryupdate, "</p>";
									}
									
									//close the database connection
									mysqli_close($connectagain);
								}//if successful database connection
			
							}
					
		
						
					
			else{		
			require_once ("settings.php");	//connection info
		
		$conn = @mysqli_connect(	$host,
									$user,
									$pwd,
									$sql_db
								);
		//checks if connection is successful
		if(!$conn){
			//displays an error message
			echo "<p>Database Connection failure</p>";	//not in production script
		}
		else  {
			//upon successful connection
			
			$sql_table="orders";
			
			//set up the SQL command to query or add data into the table
			$query = "SELECT order_id, order_time, order_cost, product_name, speaker, quantity, firstname, lastname, order_status FROM $sql_table ";
			
			if($sort=="sort"){
				$query .="ORDER BY firstname ASC";
			}
			if($sort=="revsort"){
				$query .="ORDER BY firstname DESC";
			}
			//execute the query and store result into the result pointer
			$result = mysqli_query($conn, $query);
			
			//checks if the execution was successful
			if (!$result) {
				echo "<p>Something is wrong with ", $query, "</p>";
			}
			else {
				//display the retrieved records
				echo "<table border=\"1\">\n";
				echo "<tr>\n"
					."<th scope=\"col\">Order ID</th>\n "
					."<th scope=\"col\">Order Cost</th>\n "
					."<th scope=\"col\">Order Time</th>\n "
					."<th scope=\"col\">Order Status</th>\n "
					."<th scope=\"col\"><a href='firstnamesorter.php'>Firstname</a></th>\n "//give it as link here
					."<th scope=\"col\">Lastname</th>\n "
					."<th scope=\"col\">Product Name</th>\n "
					."<th scope=\"col\">Speaker</th>\n "
					."<th scope=\"col\">Quantity</th>\n "
					."</tr>\n ";
					//the "\n" is optional. Creates tidy served code.
					
				//retieve current record pointed by the result pointer
				
				while ($row = mysqli_fetch_assoc($result)){
					echo "<tr>\n ";
					echo "<td>", $row["order_id"], "</td>\n ";
					echo "<td>", $row["order_cost"], "</td>\n ";
					echo "<td>", $row["order_time"], "</td>\n ";
					echo "<td>", $row["order_status"];
					echo"
					<form method='post' action='manager.php'>
					
					<p><label for='sProduct'> Status: </label>
				<input type=hidden name='order_id' value=".$row['order_id']. " >	
				<select name='status' id='sProduct'>
				
					<option ";
					
					if($row["order_status"]=="Pending"){echo " selected";} 
					echo " value='Pending'> Pending</option>
					<option "; 
					if($row["order_status"]=="Fulfilled"){echo " selected";} 
					echo " value='Fulfilled'>Fulfilled</option>
					<option "; 
					if($row["order_status"]=="Paid"){echo " selected";} 
					echo " value='Paid'>Paid</option>
					<option ";
					if($row["order_status"]=="Archived"){echo " selected";} 
					echo " value='Archived'>Archived</option>
			
					</select>
					<p><input id='submit' type='submit' value='Update'/> 
					</form>";
					
					if($row["order_status"]=="Pending"){
						echo"
					<form method='post' action='manager.php'>
					
						<p>
						<input type=hidden name='order_id_delete' value=".$row['order_id']. " ></p>
					
						<p><input id='submit' type='submit' value='delete'/></p> 
						</form>";
					}
					echo"
					</td>\n ";
					
					
					echo "<td>", $row["firstname"], "</td>\n ";
					echo "<td>", $row["lastname"], "</td>\n ";
					echo "<td>", $row["product_name"], "</td>\n ";
					echo "<td>", $row["speaker"], "</td>\n ";
					echo "<td>", $row["quantity"], "</td>\n ";
					echo "</tr>\n ";
				}
				echo "</table>\n ";
				
				//Frees up the memory, after using the result pointer
				mysqli_free_result($result);
			}//if successful query operation
			
			//close the database connection
			mysqli_close($conn);
		}//if successful database connection

	}
	}
	$_SESSION["sort"]=$sort;
	
	
	?>
	<p><a href="ordernamesearch.php">Orders for a customer based on their name</a></p>
	<?php
	if($object == "customername"){
		echo"<h2>Search Data Form</h2>
	<form method='post' action='manager.php'>
	<fieldset><legend>Customer Search</legend>
		<p>	<label for='lastname'>Last Name: </label>
			<input type='text' name='lastname' id='sLname' /></p>
		<p>	<input type='submit' id='submit' value='Search Customer' /></p>
	</fieldset>
	</form>
	";}
	if (isset($_POST["lastname"])){
	$lastname	= trim($_POST["lastname"]);
		if (!$lastname==""){
			require_once ("settings.php");	//connection info
		
		$conn = @mysqli_connect(	$host,
									$user,
									$pwd,
									$sql_db
								);
		//checks if connection is successful
		if(!$conn){
			//displays an error message
			echo "<p>Database Connection failure</p>";	//not in production script
		}
		else  {
			//upon successful connection
			
			$sql_table="orders";
			
			//set up the SQL command to query or add data into the table
			$query = "SELECT order_id, order_time, order_cost, product_name, speaker, quantity, firstname, lastname, order_status FROM $sql_table where lastname like '$lastname%'";
			
			//execute the query and store result into the result pointer
			$result = mysqli_query($conn, $query);
			
			//checks if the execution was successful
			if (!$result) {
				echo "<p>Something is wrong with ", $query, "</p>";
			}
			else {
				//display the retrieved records
				echo "<table border=\"1\">\n";
				echo "<tr>\n"
					."<th scope=\"col\">Order ID</th>\n "
					."<th scope=\"col\">Order Cost</th>\n "
					."<th scope=\"col\">Order Time</th>\n "
					."<th scope=\"col\">Order Status</th>\n "
					."<th scope=\"col\">Firstname</th>\n "
					."<th scope=\"col\">Lastname</th>\n "
					."<th scope=\"col\">Product Name</th>\n "
					."<th scope=\"col\">Speaker</th>\n "
					."<th scope=\"col\">Quantity</th>\n "
					."</tr>\n ";
					//the "\n" is optional. Creates tidy served code.
					
				//retieve current record pointed by the result pointer
				
				while ($row = mysqli_fetch_assoc($result)){
					echo "<tr>\n ";
					echo "<td>", $row["order_id"], "</td>\n ";
					echo "<td>", $row["order_cost"], "</td>\n ";
					echo "<td>", $row["order_time"], "</td>\n ";
					echo "<td>", $row["order_status"], "</td>\n ";
					echo "<td>", $row["firstname"], "</td>\n ";
					echo "<td>", $row["lastname"], "</td>\n ";
					echo "<td>", $row["product_name"], "</td>\n ";
					echo "<td>", $row["speaker"], "</td>\n ";
					echo "<td>", $row["quantity"], "</td>\n ";
					echo "</tr>\n ";
				}
				echo "</table>\n ";
				
				//Frees up the memory, after using the result pointer
				mysqli_free_result($result);
			}//if successful query operation
			
			//close the database connection
			mysqli_close($conn);
		}//if successful database connection

		}
	}
	?>
	<p><a href="orderproductsearch.php">Orders for a particular product</a></p>
	<?php
	if($object == "productname"){
		echo"<h2>Search Data Form</h2>
	<form method='post' action='manager.php'>
	<fieldset><legend>Customer Search</legend>
		<p>	<label for='lastname'>Product Name: </label>
			<input type='text' name='productname' id='sProduct' /></p>
		<p>	<input type='submit' id='submit' value='Search Product' /></p>
	</fieldset>
	</form>
	";}
	if (isset($_POST["productname"])){
	$productname	= trim($_POST["productname"]);
		if (!$productname==""){
			require_once ("settings.php");	//connection info
		
		$conn = @mysqli_connect(	$host,
									$user,
									$pwd,
									$sql_db
								);
		//checks if connection is successful
		if(!$conn){
			//displays an error message
			echo "<p>Database Connection failure</p>";	//not in production script
		}
		else  {
			//upon successful connection
			
			$sql_table="orders";
			
			//set up the SQL command to query or add data into the table
			$query = "SELECT order_id, order_time, order_cost, product_name, speaker, quantity, firstname, lastname, order_status FROM $sql_table where product_name like '$productname'";
			
			//execute the query and store result into the result pointer
			$result = mysqli_query($conn, $query);
			
			//checks if the execution was successful
			if (!$result) {
				echo "<p>Something is wrong with ", $query, "</p>";
			}
			else {
				//display the retrieved records
				echo "<table border=\"1\">\n";
				echo "<tr>\n"
					."<th scope=\"col\">Order ID</th>\n "
					."<th scope=\"col\">Order Cost</th>\n "
					."<th scope=\"col\">Order Time</th>\n "
					."<th scope=\"col\">Order Status</th>\n "
					."<th scope=\"col\">Firstname</th>\n "
					."<th scope=\"col\">Lastname</th>\n "
					."<th scope=\"col\">Product Name</th>\n "
					."<th scope=\"col\">Speaker</th>\n "
					."<th scope=\"col\">Quantity</th>\n "
					."</tr>\n ";
					//the "\n" is optional. Creates tidy served code.
					
				//retieve current record pointed by the result pointer
				
				while ($row = mysqli_fetch_assoc($result)){
					echo "<tr>\n ";
					echo "<td>", $row["order_id"], "</td>\n ";
					echo "<td>", $row["order_cost"], "</td>\n ";
					echo "<td>", $row["order_time"], "</td>\n ";
					echo "<td>", $row["order_status"], "</td>\n ";
					echo "<td>", $row["firstname"], "</td>\n ";
					echo "<td>", $row["lastname"], "</td>\n ";
					echo "<td>", $row["product_name"], "</td>\n ";
					echo "<td>", $row["speaker"], "</td>\n ";
					echo "<td>", $row["quantity"], "</td>\n ";
					echo "</tr>\n ";
				}
				echo "</table>\n ";
				
				//Frees up the memory, after using the result pointer
				mysqli_free_result($result);
			}//if successful query operation
			
			//close the database connection
			mysqli_close($conn);
		}//if successful database connection

		}
	}
	?>
	<p><a href="orderproductpending.php">Orders that are pending</a></p>
	<?php
	if($object == "pending"){
		
			require_once ("settings.php");	//connection info
		
		$conn = @mysqli_connect(	$host,
									$user,
									$pwd,
									$sql_db
								);
		//checks if connection is successful
		if(!$conn){
			//displays an error message
			echo "<p>Database Connection failure</p>";	//not in production script
		}
		else  {
			//upon successful connection
			
			$sql_table="orders";
			
			//set up the SQL command to query or add data into the table
			$query = "SELECT order_id, order_time, order_cost, product_name, speaker, quantity, firstname, lastname, order_status FROM $sql_table where order_status like '$object'";
			
			//execute the query and store result into the result pointer
			$result = mysqli_query($conn, $query);
			
			//checks if the execution was successful
			if (!$result) {
				echo "<p>Something is wrong with ", $query, "</p>";
			}
			else {
				//display the retrieved records
				echo "<table border=\"1\">\n";
				echo "<tr>\n"
					."<th scope=\"col\">Order ID</th>\n "
					."<th scope=\"col\">Order Cost</th>\n "
					."<th scope=\"col\">Order Time</th>\n "
					."<th scope=\"col\">Order Status</th>\n "
					."<th scope=\"col\">Firstname</th>\n "
					."<th scope=\"col\">Lastname</th>\n "
					."<th scope=\"col\">Product Name</th>\n "
					."<th scope=\"col\">Speaker</th>\n "
					."<th scope=\"col\">Quantity</th>\n "
					."</tr>\n ";
					//the "\n" is optional. Creates tidy served code.
					
				//retieve current record pointed by the result pointer
				
				while ($row = mysqli_fetch_assoc($result)){
					echo "<tr>\n ";
					echo "<td>", $row["order_id"], "</td>\n ";
					echo "<td>", $row["order_cost"], "</td>\n ";
					echo "<td>", $row["order_time"], "</td>\n ";
					echo "<td>", $row["order_status"], "</td>\n ";
					echo "<td>", $row["firstname"], "</td>\n ";
					echo "<td>", $row["lastname"], "</td>\n ";
					echo "<td>", $row["product_name"], "</td>\n ";
					echo "<td>", $row["speaker"], "</td>\n ";
					echo "<td>", $row["quantity"], "</td>\n ";
					echo "</tr>\n ";
				}
				echo "</table>\n ";
				
				//Frees up the memory, after using the result pointer
				mysqli_free_result($result);
			}//if successful query operation
			
			//close the database connection
			mysqli_close($conn);
		}//if successful database connection

		}
	
	?>
	<p><a href="orderproductcostsort.php">Orders sorted by total cost</a></p>
	<?php
	if($object == "costsort"){
		
			require_once ("settings.php");	//connection info
		
		$conn = @mysqli_connect(	$host,
									$user,
									$pwd,
									$sql_db
								);
		//checks if connection is successful
		if(!$conn){
			//displays an error message
			echo "<p>Database Connection failure</p>";	//not in production script
		}
		else  {
			//upon successful connection
			
			$sql_table="orders";
			
			//set up the SQL command to query or add data into the table
			$query = "SELECT order_id, order_time, order_cost, product_name, speaker, quantity, firstname, lastname, order_status FROM $sql_table ORDER BY order_cost";
			
			//execute the query and store result into the result pointer
			$result = mysqli_query($conn, $query);
			
			//checks if the execution was successful
			if (!$result) {
				echo "<p>Something is wrong with ", $query, "</p>";
			}
			else {
				//display the retrieved records
				echo "<table border=\"1\">\n";
				echo "<tr>\n"
					."<th scope=\"col\">Order ID</th>\n "
					."<th scope=\"col\">Order Cost</th>\n "
					."<th scope=\"col\">Order Time</th>\n "
					."<th scope=\"col\">Order Status</th>\n "
					."<th scope=\"col\">Firstname</th>\n "
					."<th scope=\"col\">Lastname</th>\n "
					."<th scope=\"col\">Product Name</th>\n "
					."<th scope=\"col\">Speaker</th>\n "
					."<th scope=\"col\">Quantity</th>\n "
					."</tr>\n ";
					//the "\n" is optional. Creates tidy served code.
					
				//retieve current record pointed by the result pointer
				
				while ($row = mysqli_fetch_assoc($result)){
					echo "<tr>\n ";
					echo "<td>", $row["order_id"], "</td>\n ";
					echo "<td>", $row["order_cost"], "</td>\n ";
					echo "<td>", $row["order_time"], "</td>\n ";
					echo "<td>", $row["order_status"], "</td>\n ";
					echo "<td>", $row["firstname"], "</td>\n ";
					echo "<td>", $row["lastname"], "</td>\n ";
					echo "<td>", $row["product_name"], "</td>\n ";
					echo "<td>", $row["speaker"], "</td>\n ";
					echo "<td>", $row["quantity"], "</td>\n ";
					echo "</tr>\n ";
				}
				echo "</table>\n ";
				
				//Frees up the memory, after using the result pointer
				mysqli_free_result($result);
			}//if successful query operation
			
			//close the database connection
			mysqli_close($conn);
		}//if successful database connection

		}
	
	?>
	<p id="enhance1"><a href="fulfilledorderbetweendays.php">Fulfilled orders purchased between two dates</a></p>
	<?php
	if($object == "fulfilledorderbetweendays"){
		echo"<h2>Search Data Form</h2>
	<form method='post' action='manager.php'>
	<fieldset><legend>Date Search</legend>
		<p>	<label for='lastname'>starting date </label>
			<input type='text' name='datestart' id='sProduct' placeholder='YYYY-MM-DD' /></p>
			<p>	<label for='lastname'>ending date </label>
			<input type='text' name='dateend' id='sProduct' placeholder='YYYY-MM-DD'/></p>
		<p>	<input type='submit' id='submit' value='Search Date Range' /></p>
	</fieldset>
	</form>
	";}
	if (isset($_POST["datestart"]) && isset($_POST["dateend"])){
	$datestart	= trim($_POST["datestart"]);
	$dateend	= trim($_POST["dateend"]);
		if (!$datestart=="" && !$dateend==""){
			require_once ("settings.php");	//connection info
		
		$connenhence = @mysqli_connect(	$host,
									$user,
									$pwd,
									$sql_db
								);
		//checks if connection is successful
		if(!$connenhence){
			//displays an error message
			echo "<p>Database Connection failure</p>";	//not in production script
		}
		else  {
			//upon successful connection
			
			$sql_tableenhence="orders";
			//yy-mm-dd format
			
			//set up the SQL command to query or add data into the table
			$queryenhence = "SELECT order_id, order_time, order_cost, product_name, speaker, quantity, firstname, lastname, order_status FROM $sql_tableenhence where order_time > '$datestart' && order_time < '$dateend' && order_status='Fulfilled'";
			
			//execute the query and store result into the result pointer
			$resultenhence = mysqli_query($connenhence, $queryenhence);
			
			//checks if the execution was successful
			if (!$resultenhence) {
				echo "<p>Something is wrong with ", $queryenhence, "</p>";
			}
			else {
				//display the retrieved records
				echo "<table border=\"1\">\n";
				echo "<tr>\n"
					."<th scope=\"col\">Order ID</th>\n "
					."<th scope=\"col\">Order Cost</th>\n "
					."<th scope=\"col\">Order Time</th>\n "
					."<th scope=\"col\">Order Status</th>\n "
					."<th scope=\"col\">Firstname</th>\n "
					."<th scope=\"col\">Lastname</th>\n "
					."<th scope=\"col\">Product Name</th>\n "
					."<th scope=\"col\">Speaker</th>\n "
					."<th scope=\"col\">Quantity</th>\n "
					."</tr>\n ";
					//the "\n" is optional. Creates tidy served code.
					
				//retieve current record pointed by the result pointer
				
				while ($row = mysqli_fetch_assoc($resultenhence)){
					echo "<tr>\n ";
					echo "<td>", $row["order_id"], "</td>\n ";
					echo "<td>", $row["order_cost"], "</td>\n ";
					echo "<td>", $row["order_time"], "</td>\n ";
					echo "<td>", $row["order_status"], "</td>\n ";
					echo "<td>", $row["firstname"], "</td>\n ";
					echo "<td>", $row["lastname"], "</td>\n ";
					echo "<td>", $row["product_name"], "</td>\n ";
					echo "<td>", $row["speaker"], "</td>\n ";
					echo "<td>", $row["quantity"], "</td>\n ";
					echo "</tr>\n ";
				}
				echo "</table>\n ";
				
				//Frees up the memory, after using the result pointer
				mysqli_free_result($resultenhence);
			}//if successful query operation
			
			//close the database connection
			mysqli_close($connenhence);
		}//if successful database connection

		}
	}
	?>
</section>	
</article>

<?php
	include_once("footer.inc");
?>


</body>
</html>	
	