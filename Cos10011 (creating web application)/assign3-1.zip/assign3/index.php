<!DOCTYPE html>
<html lang="en">
<?php
	include_once("header.inc");
?>


<body>

<?php
	include_once("menu.inc");
?>





<aside id="right"> <!--put advert here to right of page-->
<figure>

	<a href="https://www.primevideo.com/region/eu" >
		<img class="img" src="images/stream.png" alt="amazon stream advert"/>
	</a>

	<p>
		<a href="  https://www.pinterest.com/pin/561964859746504753/"> pic reference </a>
	</p>
<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

</figure>
</aside>


<article>
	<h1 id="bring_down">
		COME ONE, COME ALL!
	</h1>

	<h2>
		Buy the best tv the market has to offer!
	</h2>

	
		<aside class="into_stuff">
			<figure>
				<img  class="img" src = "images/rtv_homepage.jpg" alt="Big, Stunning Tv" />
			<!-- advert 1 src =https://arstechnica.com/gadgets/2018/01/samsungs-the-wall-tv-is-a-modular-146-inch-monster-that-uses-microled/-->
					<figcaption>
					One of our prized possesion...
					</figcaption>
				
			</figure>
			<p>
				<a href="  https://arstechnica.com/gadgets/2018/01/samsungs-the-wall-tv-is-a-modular-146-inch-monster-that-uses-microled/"> pic reference </a>
			</p>
		</aside>
	

	<section class="into_stuff">
		<h3> We have:</h3>

		<ol id="ol"><li>High Quality Product </li>
			<li>Enourmous Display </li>
			<li>Economical Price </li>
		</ol>
	</section>






	





	<section id="Faq">
	<h2> 
		FAQ (Frequently Asked Questions) 
	</h2>
	
	<ul>
		<li>Do we provide maintainence serivces to televisions we sell?
					<br/>
						<p class="faq_indent"> Yes we do. 
						<br/>
						As long as within warrenty period,
						you get free maintainance.
						<br/>
						After that, you need to pay a small fee for every other maintanence you do.
						</p>
		</li>
		<li>Do we ship our products everywhere worldwide?
					<br/>
						<p class="faq_indent"> Well, currently we just started our business 
						and thus, have outlets only in a few popular places. 
						<br/>
						But I believe we will be able to achieve this milestone in a year's time. 
						<br/>
						So, do look forward to that!
						</p>
		</li>
		<li>The Tv that arrived was broken. Will I get a refund?
					<br/>
						<p class="faq_indent"> If it's true, we will fully reimburse you with a brand new tv of the same model.  
						<br/>
						 But do make sure to send adequate proof (like pictures and stuff of the tv) to our salesteam before asking for it.
						<br/>
						</p>
		</li>
	</ul>


	</section>



</article>

<?php
	include_once("footer.inc");
?>


</body>
</html>	