/*
 *Author: SM Ragib Rezwan	ID:103172423
 *Target: enquire.php and payment.php
 *Purpose: This file is to impliment validation JavaScript on enquire and payment webpages
 *Created: 18/4/2021
 *Last updated:
 *Credits: (Any guidance/help/code? credit it here.)
 */

"use strict"; //prevents creation of global variables in functions




/* This function validated enquire page data 
and then calls the storeEnquireData(isEmail, isPost, isPhone, isWired, isBluetooth, isWifi) function 
if validation is done and everything is ok*/

function validate_enquire() {
  //initialize local variables
  var errMsg = ""; //stores the error message
  var result = true; //assumes no error

//get variables from form and check rules here
  //if something is wrong set result=false, and concatenate error message  
  
  var firstName = document.getElementById("sFname").value;
  var lastName = document.getElementById("sLname").value;
  var email = document.getElementById("sEmail").value;
  var streetAddress = document.getElementById("sSA").value;
  var suburb = document.getElementById("sSoT").value;

  var x = document.getElementById("sST").selectedIndex;
  var y = document.getElementById("sST").options;
  //used it to make it so that poeple's selection id can be called.
  //https://www.w3schools.com/jsref/prop_option_index.asp
  //there x had been used to initialize index and document.getElementById("mySelect").selectedIndex
  //was used. So selectedindex is used to call up different options in option select thing


  var postCode = document.getElementById("sPC").value;
  var phoneNumber = document.getElementById("sPN").value;

  var isEmail = document.getElementById("email").checked;
  var isPost = document.getElementById("post").checked;
  var isPhone = document.getElementById("phone").checked;

  var a = document.getElementById("sProduct").selectedIndex;
  var b = document.getElementById("sProduct").options;
  //used it to make it so that poeple's selection id can be called.
  //https://www.w3schools.com/jsref/prop_option_index.asp
  //there x had been used to initialize index and document.getElementById("mySelect").selectedIndex
  //was used. So selectedindex is used to call up different options in option select thing


  var isWired = document.getElementById("wired").checked;
  var isBluetooth = document.getElementById("Bluetooth").checked;
  var isWifi = document.getElementById("Wifi").checked;

  var quantity = document.getElementById("sQuantity").value;


var debug=true;
	if(!debug){

  if (!firstName.match(/^[a-zA-Z]{1,25}$/)) {//25 alphabet character
    errMsg = errMsg + "Your first name must only contain 25 alpha characters\n";
    result = false;
  }

  if (!lastName.match(/^[a-zA-Z]{1,25}$/)) {//25 alphabet character 
    errMsg = errMsg + "Your last name must only contain 25 alpha characters\n";
    result = false;
  }
	if (!email.match(/^.+@.+\..{2,3}$/)){ //taken from lect02 regular expression, common expression list, (eg victor41@google.com)
		errMsg = errMsg + "Please give a valid email address\n";
    result = false;
	}
  if (!streetAddress.match(/^[a-zA-Z0-9 ]{1,40}$/)) {//40 alphabet or number character with space
    errMsg = errMsg + "Your street address must only contain 40 alphanumeric characters with space\n";
    result = false;
  }

  if (!suburb.match(/^[a-zA-Z0-9 ]{1,20}$/)) {//20 alphabet or number character with space
    errMsg = errMsg + "Your suburb must only contain 20 alphanumeric characters with space. \n";
    result = false;
  }

  /* at least one state selected */
  if (y[x].index == 0) {//used Index of state here to compare
    errMsg += "Please select at least one state. \n";
    result = false;
  } else {

/* calls function to do the state to specific post code validations*/
    var tempAMsg = checkStateToPostCode(y[x].index, postCode);
    if (tempAMsg != "") {//used Index of state here to make the error message via calling a function
      errMsg = errMsg + tempAMsg;
      result = false;
    }
  }




  if (!postCode.match(/^\d{4}$/)) {//only 4 digits
    errMsg = errMsg + "Your post code must only contain 4 digits\n";
    result = false;
  }

  if (!phoneNumber.match(/^\d{10}$/)) {//only 10 digits
    errMsg = errMsg + "Your phone number must only contain 10 digits\n";
    result = false;
  }

  /* at least one preferred contact selected */
  if (!(isEmail || isPost || isPhone)) {
    errMsg += "Please select at least one preferred Contact. \n";
    result = false;
  }

  /* at least one product selected */
  if (b[a].index == 0) {
    errMsg += "Please select at least one product. \n";
    result = false;
  }

  /* at least one feature selected */
  if (!(isWired || isBluetooth || isWifi)) {
    errMsg += "Please select at least one feature. \n";
    result = false;
  }

  if (isNaN(quantity)) {//quantity must be a number
    errMsg = errMsg + "Your quantity must be a number\n";
    result = false;
  } else if (quantity <= 0) {//quantity must be positive number
    errMsg = errMsg + "Your quantity must be a positive number\n";
    result = false;
  }	else if (quantity >= 10000) {//quantity can't be greater than 10,000
    errMsg = errMsg + "Your quantity can't be greater than 10,000\n";
    result = false;
}




  if (errMsg != "") { //only display message box if there is something to show
    alert(errMsg);

  }
	}
  
  
  
  
  if (result) { //if the form validates ok
    
    storeEnquireData(isEmail, isPost, isPhone, isWired, isBluetooth, isWifi);
  }
  return result; //if false the information will not be sent to the server
}

/* This function does the state to specific post code validations*/
function checkStateToPostCode(stateIndex, postCode) {
  var errMsg = "";
  switch (stateIndex) {
    case 1:
      if (!((postCode.match(/^[38]\d{3}$/)) )) {//start with 3 or 8 as a single digit, then 3 random digit
        errMsg += "VIC must start postcode with 3 or 8 \n";
      }
      break;
    case 2:
      if (!((postCode.match(/^[12]\d{3}$/)) )) {//start with 1 or 2 as a single digit, then 3 random digit
        errMsg += "NSW must start postcode with 1 or 2 \n";
      }
      break;
    case 3:
      if (!((postCode.match(/^[49]\d{3}$/)) )) {//start with 4 or 9 as a single digit, then 3 random digit
        errMsg += "QLD must start postcode with 4 or 9 \n";
      }
      break;
    case 4:
      if (!((postCode.match(/^0\d{3}$/)))) {//start with 0 as a single digit, then 3 random digit
        errMsg += "NT must start postcode with 0 \n";
      }
      break;
    case 5:
      if (!((postCode.match(/^6\d{3}$/)))) {//start with 6 as a single digit, then 3 random digit
        errMsg += "WA must start postcode with 6 \n";
      }
      break;
    case 6:
      if (!((postCode.match(/^5\d{3}$/)))) {//start with 5 as a single digit, then 3 random digit
        errMsg += "SA must start postcode with 5 \n";
      }
      break;
    case 7:
      if (!((postCode.match(/^7\d{3}$/)))) {//start with 7 as a single digit, then 3 random digit
        errMsg += "TAS must start postcode with 7 \n";
      }
      break;
    case 8:
      if (!((postCode.match(/^0\d{3}$/)))) {//start with 0 as a single digit, then 3 random digit
        errMsg += "ACT must start postcode with 0 \n";
      }
      break;
  }

  return errMsg;
}

/* This function stores the data using sessionStorage*/
function storeEnquireData(isEmail, isPost, isPhone, isWired, isBluetooth, isWifi) {
  //get value and assign them to a sessionStorage attribute.
  //we use the same name for the attribute and ethe element id to avoid confusion
  var contact = "";
  if (isEmail) contact = "Email,";
  if (isPost) contact += " Post,";
  if (isPhone) contact += " Phone"; //just concatanated all checkbox into single string

  var speaker = "";
  if (isWired) speaker = "wired,";
  if (isBluetooth) speaker += " bluetooth,";
  if (isWifi) speaker += " wifi"; //just concatanated all checkbox into single string

  sessionStorage.contact = contact; //for contact (email, post, phone)
  sessionStorage.speaker = speaker; //for speaker (Wired, Bluetooth, Wireless)

  sessionStorage.firstname = document.getElementById("sFname").value;
  sessionStorage.lastname = document.getElementById("sLname").value;
  sessionStorage.email = document.getElementById("sEmail").value;
  sessionStorage.streetAddress = document.getElementById("sSA").value;
  sessionStorage.suburb = document.getElementById("sSoT").value;
  sessionStorage.postCode = document.getElementById("sPC").value;
  sessionStorage.phoneNumber = document.getElementById("sPN").value;
  sessionStorage.quantity = document.getElementById("sQuantity").value;
  sessionStorage.comment = document.getElementById("sComment").value;

  var x = document.getElementById("sST").selectedIndex;
  var y = document.getElementById("sST").options;
  var stateText = y[x].text;
  //will give the state name, reference: 
  //https://www.w3schools.com/jsref/prop_option_index.asp
  sessionStorage.stateText = stateText;


  var a = document.getElementById("sProduct").selectedIndex;
  var b = document.getElementById("sProduct").options;
  var productText = b[a].text;
  //will give the product name, reference: 
  //https://www.w3schools.com/jsref/prop_option_index.asp
  sessionStorage.productText = productText;
  
}


/*will validate the data in payment.php*/
function validate_payment() {
  //initialize local variables
  var errMsg = ""; //stores the error message
  var result = true; //assumes no error

  //get variables from from and check rules here
  //if something is wrong set result=false, and concatenate error message
  //...
  var c = document.getElementById("sCT").selectedIndex;
  var d = document.getElementById("sCT").options;
  var cardName = document.getElementById("sCname").value;
  var cardNumber = document.getElementById("sCnumber").value;
  var expiryDate = document.getElementById("sEdate").value;
  var CVV = document.getElementById("sCVV").value;

var debug=true;
	if(!debug){
/* at least one card type must be selected */
  if (d[c].index == 0) {
    errMsg += "Credit Card must be of Visa, Mastercard, or American Express. \n";
    result = false;
  }

  if (!cardName.match(/^[a-zA-Z ]{1,40}$/)) {//40 character alphabet
    errMsg = errMsg + "Your name on credit card must only contain 40 alpha characters with space\n";
    result = false;
  }

  if (!cardNumber.match(/^[0-9]{15,16}$/)) {//15 to 16 digit number
    errMsg = errMsg + "Your credit card number must be between 15 to 16 digits\n";
    result = false;
  }
  /*check card type with card number*/
  /*didnt put it in "else" as i wanted it to check the card type with card number simultaneously while running the previous card number restriction*/
  var tempAMsg = checkCreditTypeWithNumber(d[c].index, cardNumber);
  if (tempAMsg != "") {
    errMsg = errMsg + tempAMsg;
    result = false;
  }


  if (!expiryDate.match(/^\0[1-9]|1[012]\-\d{2}$/)) { 
  //0[1-9]|1[012] restricting data from 01 to 12 for month and restrict year to 2 digit
    errMsg = errMsg + "Expiry date must be in mm-yy format\n";
    result = false;
  }
	if (isNaN(CVV)) {//CVV must be a number
    errMsg = errMsg + "Your CVV must be a number\n";
    result = false;}
  if (!CVV.match(/^\d{3}$/)) {//3 random digits
    errMsg = errMsg + "CVV is only 3 digits long!\n";
    result = false;
  }
	}

  if (errMsg != "") { //only display message box if there is something to show
    alert(errMsg);

  }

  return result; //if false the information will not be sent to the server

}
/*check card type with card number*/
function checkCreditTypeWithNumber(CardTypeIndex, cardNumber) {
  var errMsg = "";
  switch (CardTypeIndex) {
    case 1:
      if (!((cardNumber.match(/^4\d{15}$/)))) {//start with 4, then 15 random digits
        errMsg += "Visa Card must start with 4 and be 16 digits long \n" ;


      }
      break;
    case 2:
      if (!((cardNumber.match(/^5[1-5]\d{14}$/)) )) {//start with 5, then 1-5 any single digit, then 14 rest random digit
        errMsg += "Mastercard must start with digits 51 to 55 and be 16 digits long\n";
      }
      break;
    case 3:
      if (!((cardNumber.match(/^3[47]\d{13}$/)) )) {//start with 3, then 4 or 7 any specific digit, then 13 rest any random digit
        errMsg += "American Express must start with digits 34 or 37 and be 15 digits long \n";
      }
      break;
  }
  return errMsg;

}


//This should be really be calculated securely on the server!
//it calculates the total cost of purchase 
function calcCost(quantity, speaker, product){
	var cost = 0;
	if (product.match("Stark")) cost = 10000;
	if (product.match("Vibranium")) cost = 12000;
	if (product.match("PUBGMania")) cost = 8000;
	
	
	if (speaker.match("wired,") > 0) cost += 300;
	if (speaker.match("bluetooth,")> 0) cost += 500;
	if (speaker.match("wifi")> 0) cost += 600;
	cost = cost * quantity;
	
	return cost;
}
/*takes data from enquire and puts it in payment*/
function transferDataToPayment(){
	var cost = 0;
	if(sessionStorage.firstname != undefined){    //if sessionStorage for username is not empty
		
		//linking all confirmation text with stored data via sessionStorage
		document.getElementById("confirm_name").textContent = sessionStorage.firstname + " " + sessionStorage.lastname;
		document.getElementById("confirm_email").textContent =sessionStorage.email;
		document.getElementById("confirm_street_address").textContent = sessionStorage.streetAddress;
		document.getElementById("confirm_suburb").textContent = sessionStorage.suburb;
		document.getElementById("confirm_state").textContent =sessionStorage.stateText;
		document.getElementById("confirm_post_code").textContent = sessionStorage.postCode;
		document.getElementById("confirm_phone_number").textContent = sessionStorage.phoneNumber;
		document.getElementById("confirm_contact").textContent = sessionStorage.contact;
		document.getElementById("confirm_product").textContent = sessionStorage.productText;
		document.getElementById("confirm_speaker").textContent = sessionStorage.speaker;
		document.getElementById("confirm_quantity").textContent = sessionStorage.quantity;
		document.getElementById("confirm_comment").textContent = sessionStorage.comment;
		
		//calculating cost part, to called the function and linked it to variable
		cost = calcCost(sessionStorage.quantity, sessionStorage.speaker, sessionStorage.productText);
		document.getElementById("confirm_cost").textContent = cost;
		
		//fill hidden fields in page of payment
		document.getElementById("firstname").value = sessionStorage.firstname;
		document.getElementById("lastname").value = sessionStorage.lastname;
		document.getElementById("email").value = sessionStorage.email;
		document.getElementById("streetAddress").value = sessionStorage.streetAddress;
		document.getElementById("suburb").value = sessionStorage.suburb;
		document.getElementById("stateText").value = sessionStorage.stateText;
		document.getElementById("postCode").value = sessionStorage.postCode;
		document.getElementById("phoneNumber").value = sessionStorage.phoneNumber;
		document.getElementById("contact").value = sessionStorage.contact;
		document.getElementById("productText").value = sessionStorage.productText;
		document.getElementById("speaker").value = sessionStorage.speaker;
		document.getElementById("quantity").value = sessionStorage.quantity;
		document.getElementById("comment").value = sessionStorage.comment;
		
		document.getElementById("cost").value = cost; //this is because we are calculating cost here on this page and the adding is coming from calc function. So no need sessionStorage for this
	}

}

/*function for cancelling sending data from payment.php to mercury server's formtest.php */
function cancelPayment(){
	//when cancelled, will move back to index.php and delete previously stored data
	
	sessionStorage.clear(); //clear all stored data
	window.location = "index.php";//returns back to index.php
	
}

/*Calling the all the main functions once the Window loads*/
function init() {
	
  if (document.getElementById("enquire") !== null) {
    var enquireForm = document.getElementById("enquire"); // get ref to the HTML element for enquire
	
	
    enquireForm.onsubmit = validate_enquire; //register the event listener for enquire 
	//turned off all validation parts from inside the enquire, making sure result remains true and hence passed the data
		

  }
  if (document.getElementById("payment") !== null) {
    var paymentForm = document.getElementById("payment"); // get ref to the HTML element for payment
	
	
    paymentForm.onsubmit = validate_payment; //register the event listener for payment//
	//turned off all validation parts from inside the enquire, making sure result remains true and hence passed the data
	
	
	transferDataToPayment();//to transfer the data to Payment
	enhancement();//links the enhancement javascript by calling this function, 
	//as the enhancement function is unique to enhancement javascript webpage
	
	var cancel = document.getElementById("reset");//get ref to HTML element for cancel part in payment
	cancel.onclick = cancelPayment; //to cancel payment, destroy data and go back to index
  }
}

window.onload = init; //runs when window loads
