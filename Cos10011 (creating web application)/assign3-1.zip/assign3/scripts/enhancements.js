/*
 *Author: SM Ragib Rezwan	ID:103172423
 *Target: payment.html
 *Purpose: This file is to impliment validation JavaScript on payment webpage
 *Created: 20/4/2021
 *Last updated:
 *Credits: (Any guidance/help/code? credit it here.)
		1) reference for countdown timer: https://codepen.io/rxsharp/pen/jPZgpX
		2) reference for concatenation of firstname and last name to credit card:
			a)https://www.w3schools.com/html/html_form_attributes.asp
			b)https://www.w3schools.com/jsref/prop_win_sessionstorage.asp
 */

"use strict"; //prevents creation of global variables in functions

/* countdown timer part:*/
function countdown( elementName, minutes, seconds )
{
    var element, endTime, hours, mins, msLeft, time;//all variables used here

    function twoDigits( n )//function to determine min:sec format
    {
        return (n <= 9 ? "0" + n : n);
    }

    function updateTimer()
    {
        msLeft = endTime - (+new Date);
        if ( msLeft < 1000 ) {//when less than 1 second, send home
            send_home();
        } else {
            time = new Date( msLeft );
            hours = time.getUTCHours(); //javascript method to return hour
            mins = time.getUTCMinutes();//javascript method to return min
            element.innerHTML = (hours ? hours + ':' + twoDigits( mins ) : mins) + ':' + twoDigits( time.getUTCSeconds() );//changing the output given in text on webpage
            setTimeout( updateTimer, time.getUTCMilliseconds() + 500 ); //keep running this specific function after a certain time
        }
    }

    element = document.getElementById( elementName );
    endTime = (+new Date) + 1000 * (60*minutes + seconds) + 500;//time when stops = time now + duration i want it to stop after
    updateTimer(); //calls the update timer function
}

/* countdown timer part:*/
function send_home(){//pops up box warning user and then sends him back to Home
	alert("Times up! Redirecting back to Home now");//the warning
	window.location = "index.php"; //sends back to home
}

/* Concatenate first and last name to credit card input field part*/
function prefill_credit_card_info(){
	document.getElementById("sCname").value = sessionStorage.firstname + " " + sessionStorage.lastname;//takes in first adn last anme from storage and puts it in value place of elemt with id sCname. Here value is used as input box of type text.
}


function enhancement() {
  countdown( "countdown", 5,  0); //calls countdown function
	
	prefill_credit_card_info();
}
