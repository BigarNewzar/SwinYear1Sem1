<?php
session_start();	//start the session
	$object = $_SESSION["object"];//copy the value to a variable
	$object = "costsort";					//decrement the value
	$_SESSION["object"] = $object;	//update the session varible
	header("location:manager.php")

?>
