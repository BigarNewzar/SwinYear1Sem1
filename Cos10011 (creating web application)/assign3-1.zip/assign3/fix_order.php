<?php 
session_start();
if(isset($_SESSION["logCorrect"])){

     		//start the session
	if (!isset ($_SESSION["number"])){	//check if session variable exists
		$_SESSION["number"] = 0;		//create and set the session variable
	}
	$firstname = $_SESSION["firstname"];
	$lastname = $_SESSION["lastname"];
	$email = $_SESSION["email"];
	$street_address = $_SESSION["street_address"];
	$suburb = $_SESSION["suburb"];
	$state = $_SESSION["state"];
	$postcode = $_SESSION["postcode"];
	$phone_number = $_SESSION["phone_number"];
	$contact = $_SESSION["contact"];
	$product = $_SESSION["product"];
	$features = $_SESSION["features"];
	$quantity = $_SESSION["quantity"];
	$comment = $_SESSION["comment"];
	
	
$card_type = $_SESSION["ctype"];
$card_name = $_SESSION["cname"];
$card_number = $_SESSION["cnumber"];
$card_expiry_date = $_SESSION["cexpiry"];
$card_verification_value = $_SESSION["cCVV"];
$cost = $_SESSION["cost"];
	
	function checkStateToPostCode($state, $postcode) {
	$errMsg2 = "";
	switch ($state){
    case "VIC":
      if (!preg_match("/^[38]\d{3}$/",$postcode)) {//start with 3 or 8 as a single digit, then 3 random digit
        $errMsg2 .= "VIC must start postcode with 3 or 8 \n";
      }
      break;
	case "NSW":
      if (!preg_match("/^[12]\d{3}$/",$postcode)) {//start with 1 or 2 as a single digit, then 3 random digit
        $errMsg2 .= "NSW must start postcode with 1 or 2 \n";
      }
      break;
	case "QLD":
      if (!preg_match("/^[49]\d{3}$/",$postcode)) {//start with 4 or 9 as a single digit, then 3 random digit
        $errMsg2 .= "QLD must start postcode with 4 or 9 \n";
      }
      break;
	case "NT":
      if (!preg_match("/^0\d{3}$/",$postcode)) {//start with 0 as a single digit, then 3 random digit
        $errMsg2 .= "NT must start postcode with 0 \n";
      }
      break;
	case "WA":
      if (!preg_match("/^6\d{3}$/",$postcode)) {//start with 6 as a single digit, then 3 random digit
        $errMsg2 .= "WA must start postcode with 6 \n";
      }
      break;
	case "SA":
      if (!preg_match("/^5\d{3}$/",$postcode)) {//start with 5 as a single digit, then 3 random digit
        $errMsg2 .= "SA must start postcode with 5 \n";
      }
      break; 
	case "TAS":
      if (!preg_match("/^7\d{3}$/",$postcode)) {//start with 7 as a single digit, then 3 random digit
        $errMsg2 .= "TAS must start postcode with 7 \n";
      }
      break; 
	case "ACT":
      if (!preg_match("/^0\d{3}$/",$postcode)) {//start with 0 as a single digit, then 3 random digit
        $errMsg2 .= "ACT must start postcode with 0 \n";
      }
      break; 
	}
	return $errMsg2;
	}
	
function checkCreditTypeWithNumber($card_type, $card_number) {
   $errMsg3 = "";
  switch ($card_type) {
	case "Visa":
      if (!preg_match("/^4\d{15}$/",$card_number)) {//start with 4, then 15 random digits
        $errMsg3 .= "Visa Card must start with 4 and be 16 digits long \n";
      }

      break;
    case "Mastercard":
      if (!preg_match("/^5[1-5]\d{14}$/",$card_number)) {//start with 5, then 1-5 any single digit, then 14 rest random digit
        $errMsg3 .= "Mastercard must start with digits 51 to 55 and be 16 digits long\n";
      }

      break;
    case "American_Express":
      if (!preg_match("/^3[47]\d{13}$/",$card_number)) {//start with 3, then 4 or 7 any specific digit, then 13 rest any random digit
        $errMsg3 .= "American Express must start with digits 34 or 37 and be 15 digits long \n";
      }

      break;
    
  }
  return $errMsg3;

}
echo"
<!DOCTYPE html>
<html lang='en'>";

	include_once("header.inc");


echo"
<body>";


	include_once("menu.inc");





echo"
<aside id='right'> <!--put advert here to right of page-->
<figure>

	<a href='https://www.primevideo.com/region/eu' >
		<img class='img' src='images/stream.png' alt='amazon stream advert'/>
	</a>

	<p>
		<a href='  https://www.pinterest.com/pin/561964859746504753/'> pic reference </a>
	</p>
<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

</figure>
</aside>



<h1 id='bring_down'>Product Payment details:</h1>

<article id= 'Faq_no_b'>

<section>
<form id='payment' method='post' novalidate='novalidate' action='process_order.php'>
<fieldset>";

echo"
<legend>Customer details: </legend>
<!--added this part as data will be linked to these ids. these are 'keys'-->

<p><label for='sFname'> First Name </label>
	<input type='text' name='firstname' id='sFname' value='$firstname'/>";


    if ($firstname==""){
		echo "<em>You must enter your first name.</em>";
	}
	else if (!preg_match("/^[a-zA-Z]{1,25}$/", $firstname)){
		echo "<em>Your first name must only contain 25 alpha characters\n</em>";
	}

echo"
</p>
<p>
	<label for='sLname'> Last Name </label>
	<input type='text' name='lastname' id='sLname' value='$lastname' />" ;
	

    	if ($lastname==""){
		echo "<em>You must enter your last name.</em>";
	}
	else if (!preg_match("/^[a-zA-Z]{1,25}$/", $lastname)){
		echo "<em>Your last name must only contain 25 alpha characters\n</em>";
	}

echo"
</p>
	<label for='sEmail'>Email Address:</label>
	<input type='email' name='email' id='sEmail' value='$email'/>";
	

    	if ($email==""){
		echo "<em>You must enter your email.</em>";
	}
	else if (!preg_match("/^.+@.+\..{2,3}$/", $email)){//taken from lect02 regular expression, common expression list, (eg victor41@google.com)
		echo "<em>Please give a valid email address\n</em>";
	}
	

echo"

	<p><label for='sSA'> Street address:</label>
	<input type='text' name='streetAddress' id='sSA' value='$street_address'/>"; 
	

    	if ($street_address==""){
		echo "<em>You must enter your street address.</em>";
	}
	else if (!preg_match("/^[a-zA-Z0-9 ]{1,40}$/", $street_address)){
		echo "<em>Your street address must only contain 40 alphanumeric characters with space\n</em>";
	}
	

echo"
	</p>
	
	<p><label for='sSoT'> Suburb/town: </label>
	<input type='text' name='suburb' id='sSoT' value='$suburb'/>"; 


    	if ($suburb==""){
		 echo "<em>You must enter your suburb.</em>";
	}
	else if (!preg_match("/^[a-zA-Z0-9 ]{1,20}$/", $suburb)){
		 echo "<em>Your suburb must only contain 20 alphanumeric characters with space. \n</em>";
	}
	

echo "
	
	</p>
	
	<p><label for='sST'> State: </label>
		<select name='stateText' id='sST' >
			<option ";
			if($state=="Please Select"){echo " selected";}
			
			echo " value='' > Please Select</option>
			<option "; 
			if($state=="VIC"){echo " selected";}
			echo " value='VIC' >VIC</option>
			<option "; 
			if($state=="NSW"){echo " selected";}
			echo " value='NSW' >NSW</option>
			<option "; 
			if($state=="QLD"){echo " selected";}
			echo " value='QLD' >QLD</option>
			<option " ;
			if($state=="NT"){echo " selected";}
			echo " value='NT' >NT</option>
			<option " ;
			if($state=="WA"){echo " selected";}
			echo " value='WA' >WA</option>
			<option "; 
			if($state=="SA"){echo " selected";}
			echo " value='SA' >SA</option>
			<option "; 
			if($state=="TAS"){echo " selected";}
			echo " value='TAS' >TAS</option>
			<option "; 
			if($state=="ACT"){echo " selected";}
			echo " value='ACT' >ACT</option>
		</select>";
			

    	if ($state=="Please Select"){
		 echo "<em>Please Enter a state</em>";
	}
	

echo"
		
		
	</p>
	
	<p><label for='sPC'> Postcode: </label>
		<input type='text' name='postCode' id='sPC' value='$postcode'  placeholder='####'/>" ;
		
    	if ($postcode==""){
		echo "<em>You must enter your postcode.</em>";
	}
	else if (!preg_match("/^\d{4}$/", $postcode)){//only 4 digits
		echo "<em>Your post code must only contain 4 digits\n</em>";
	}
	else{
		$tempAMsg = checkStateToPostCode($state, $postcode);
		if ($tempAMsg != "") {
      echo "<em>". $tempAMsg ."</em>";
      	}
	}

echo"
	</p>



<p><label for='sPN'> Phone Number: </label>
		<input type='text' name='phoneNumber' id='sPN' value='$phone_number' placeholder='##########'/>"; 
		

    	if ($phone_number==""){
		echo "<em>You must enter your phone number.</em>";
	}
	else if (!preg_match("/^\d{10}$/", $phone_number)){//only 10 digits
		echo "<em>Your phone number must only contain 10 digits\n</em>";
	}

echo"
</p>
<p><label> Preferred Contact: </label>
	<label for='email'>
	<input type='radio' id='email' name='contact' value='Email,'";
	if($contact=="Email,")echo "checked='checked'";
	echo"/>Email </label>
	
	<label for='post'>
	<input type='radio' id='post' name='contact' value='Post,'";
	if($contact=="Post,")echo "checked='checked'";
	echo"/>Post </label>
	
	<label for='phone'>
	<input type='radio' id='phone' name='contact' value='Phone'";
	if($contact=="Phone")echo "checked='checked'";
	echo"/>Phone </label>";	
	

    	if($contact==""){
		echo "<em>Please select at least one preferred Contact. \n</em>";
	}

echo"
</p>


<p><label for='sProduct'> Product: </label>
		<select name='productText' id='sProduct'>
			<option ";
			if($product=="Please Select"){echo " selected";} 
			echo " value=''> Please Select</option>
			<option "; 
			if($product=="Stark"){echo " selected";} 
			echo " value='Stark'>Stark</option>
			<option "; 
			if($product=="Vibranium"){echo " selected";} 
			echo " value='Vibranium'>Vibranium</option>
			<option ";
			if($product=="PUBGMania"){echo " selected";} 
			echo " value='PUBGMania'>PUBG Mania</option>
			
		</select>";
		

    	if ($product=="Please Select"){
		echo "<em>Please select at least one product. \n</em>";
	}

echo"
</p>
<p>

<p>
<label> Product features:</label>


	<label for='wired'><input type='checkbox' id='wired' name='wired' value='wired' ";
	if($features=="wired,"|| $features=="wired, bluetooth, wifi" || $features=="wired, bluetooth," || $features=="wired, wifi")echo "checked='checked'"; 
	echo"/> Wired Speakers</label>
	
	<label for='Bluetooth'><input type='checkbox' id='bluetooth' name='bluetooth' value='bluetooth'"; 
	if($features=="bluetooth,"|| $features=="wired, bluetooth, wifi" || $features=="wired, bluetooth," || $features=="bluetooth, wifi")echo "checked='checked'"; 
	echo"/> Bluetooth Speakers</label>
	
	<label for='Wifi'><input type='checkbox' id='wifi' name='wifi' value='wifi'"; 
	if($features=="wifi"|| $features=="wired, bluetooth, wifi" || $features=="wired, wifi" || $features=="bluetooth, wifi")echo "checked='checked'"; 
	echo"/> Wifi Speakers</label>";
	

    	if($features==""){
		echo "<em>Please select at least one feature. \n</em>";
		
	}

echo"
	
</p>

<p><label for='sQuantity'>Quantity of product: </label> <br/>
<input type='text' name='quantity' id='sQuantity' value='$quantity' size='5'>";


    	if (!is_numeric($quantity)){//quantity must be a number
		echo "<em>Your quantity must be a number\n</em>";
	}
	else if ($quantity < 0 || $quantity > 10000){
		echo "<em>Your quantity must be between 0 and 10,000\n</em>";
	}

echo"
</p>

<p><label for='sComment'> Comment 	</label> <br/>
	<textarea name='comment' rows='4' cols='25' id='sComment' placeholder='$comment'></textarea>
</p>
		<!--key value for price that will be calculated here later-->
		<p>Total Price of Purchase: $<em  id='confirm_cost'>". $cost."</em></p>
		
		
		<!--added this part as data will be passed in here from enquire as hidden values for now, these are 'values'-->
		
		
		
</fieldset>


<!--Form data unique to payment-->

<fieldset><legend>Credit Card Details: </legend>
<p><label for='sCT'> Credit Card Type: </label>
		<select name='pCT' id='sCT' >
			<option value='' selected='selected'> Please Select</option>
			<option value='Visa' >Visa</option>
			<option value='Mastercard'>Mastercard</option>
			<option value='American_Express'>American Express</option>
		</select>";
		

    if ($card_type==""){
		echo "<em>Credit Card must be of Visa, Mastercard, or American Express. \n</em>";
	}

echo"
	</p>
<p>
	<label for='sCname'>Name on Credit Card:</label>
	<input type='text' name='pCna' id='sCname'/>";
	

    if ($card_name==""){
		echo "<em>You must enter your name on credit card.</em>";
	}
	else if (!preg_match("/^[a-zA-Z ]{1,40}$/", $card_name)){
		echo "<em>Your name on credit card must only contain 40 alpha characters with space\n </em>";
	}

echo"
</p>
<p>
	<label for='sCnumber'>Credit Card Number:</label>
	<input type='text' name='pCnu' id='sCnumber'/>";
	

    if ($card_number==""){
		echo "<em>You must enter your credit card number.</em>";
	}
	else if (!preg_match("/^[0-9]{15,16}$/", $card_number)){
		echo "<em> Your credit card number must be between 15 to 16 digits\n </em>";
	}
	
	$tempAMsg2 = checkCreditTypeWithNumber($card_type, $card_number);
  if ($tempAMsg2 != "") {
    echo"<em>" .$tempAMsg2."\n </em>";
    
  }

echo"
	
</p>
<p>
	<label for='sEdate'>Credit Card Expiration Date:</label>
	<input type='text' name='pEdate' id='sEdate' placeholder='mm-yy' />";
	

    if ($card_expiry_date==""){
		echo "<em>You must enter credit card Expiry Date.\n </em>";
	}
	
	//Warning: preg_match(): Null byte in regex in /home/students/accounts/s103172423/cos10011/www/htdocs/testing/process_order.php on line 258
//how to solve this and give mm-yy format for date?	
	else if (!preg_match("/^(0[1-9]|1[012])-([0-9]{2})$/", $card_expiry_date)){//0[1-9]|1[012] restricting data from 01 to 12 for month and restrict year to 2 digit
		echo "<em>Expiry date must be in mm-yy format\n </em>";
	}
	
	

echo"
</p>
<p>
	<label for='sCVV'>Card Verification Value: (CVV)</label>
	<input type='text' name='pCVV' id='sCVV' placeholder='###' />";
	

    if (!is_numeric($card_verification_value)){//CVV must be a number
		echo "<em>Your CVV must be a number\n </em>";
	}
	else if (!preg_match("/^\d{3}$/", $card_verification_value)){
		echo "<em> CVV is only 3 digits long!\n </em>";
	}
	
	

echo"
</p>
</fieldset>

<p><input id='submit' type='submit' value='Check Out'/> 
<!--when clicked, sends all datas to formtest.php -->
<input id='reset' type='reset' value='Cancel Order'/> 
<!--when clicked, resets data and sends user to homepage using javascript-->
</p>


</form>



</section>


</article>";




	include_once("footer.inc");

echo"
</body>
</html>";	


}

else{

     echo "You cannot access this page directly";

}
		