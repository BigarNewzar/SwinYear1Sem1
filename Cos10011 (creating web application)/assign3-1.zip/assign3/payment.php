<!DOCTYPE html>
<html lang="en">
<?php
	include_once("header.inc");
?>


<body>

<?php
	include_once("menu.inc");
	session_start();
	if(!isset($_SESSION["logCorrect"])){
		$_SESSION["logCorrect"]=true;
	}
?>





<aside id="right"> <!--put advert here to right of page-->
<figure>

	<a href="https://www.primevideo.com/region/eu" >
		<img class="img" src="images/stream.png" alt="amazon stream advert"/>
	</a>

	<p>
		<a href="  https://www.pinterest.com/pin/561964859746504753/"> pic reference </a>
	</p>
<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

</figure>
</aside>



<h1 id="bring_down">Product Payment details:</h1>

<article id= "Faq_no_b">

<p id="center"> Time left to submit the form: <em id="countdown">Countdown Clock will be displayed here from start if everything is ok</em>  </p>
<section>
<form id="payment" method="post" novalidate="novalidate" action="process_order.php">
<fieldset>
<legend>Customer details: </legend>
<!--added this part as data will be linked to these ids. these are "keys"-->
		<p>Your Name: <em id="confirm_name"></em></p>
		<p>Email: <em id="confirm_email"></em></p>
		<p>Street Address: <em id="confirm_street_address"></em></p>
		<p>Suburb/Town: <em  id="confirm_suburb"></em></p>
		<p>State: <em  id="confirm_state"></em></p>
		<p>Post Code: <em  id="confirm_post_code"></em></p>
		<p>Phone Number: <em  id="confirm_phone_number"></em></p>
		<p>Contact: <em  id="confirm_contact"></em></p>
		<p>Product: <em  id="confirm_product"></em></p>
		<p>Speaker: <em  id="confirm_speaker"></em></p>
		<p>Quantity: <em  id="confirm_quantity"></em></p>
		<p>Comment: <em  id="confirm_comment"></em></p> 
		
		<!--key value for price that will be calculated here later-->
		<p>Television Price only: $<em  id="confirm_cost"></em></p>
		
		
		<!--added this part as data will be passed in here from enquire as hidden values for now, these are "values"-->
		<input type="hidden" name="firstname" id="firstname" />
		<input type="hidden" name="lastname" id="lastname" />		
		<input type="hidden" name="email" id="email" />
		<input type="hidden" name="streetAddress" id="streetAddress" />
		<input type="hidden" name="suburb" id="suburb" />
		<input type="hidden" name="stateText" id="stateText" />
		<input type="hidden" name="postCode" id="postCode" />
		<input type="hidden" name="phoneNumber" id="phoneNumber" />
		<input type="hidden" name="contact" id="contact" />
		<input type="hidden" name="productText" id="productText" />
		<input type="hidden" name="speaker" id="speaker" />
		<input type="hidden" name="quantity" id="quantity" />
		<input type="hidden" name="comment" id="comment" /> 
		<input type="hidden" name="cost" id="cost" />
		
		
</fieldset>


<!--Form data unique to payment-->

<fieldset><legend>Credit Card Details: </legend>
<p><label for="sCT"> Credit Card Type: </label>
		<select name="pCT" id="sCT" >
			<option value="" selected="selected"> Please Select</option>
			<option value="Visa" >Visa</option>
			<option value="Mastercard">Mastercard</option>
			<option value="American_Express">American Express</option>
		</select>
	</p>
<p>
	<label for="sCname">Name on Credit Card:</label>
	<input type="text" name="pCna" id="sCname"/> 
</p>
<p>
	<label for="sCnumber">Credit Card Number:</label>
	<input type="text" name="pCnu" id="sCnumber"/>
</p>
<p>
	<label for="sEdate">Credit Card Expiration Date:</label>
	<input type="text" name="pEdate" id="sEdate" placeholder="mm-yy" />
</p>
<p>
	<label for="sCVV">Card Verification Value: (CVV)</label>
	<input type="text" name="pCVV" id="sCVV" placeholder="###" />
</p>
</fieldset>

<p><input id="submit" type="submit" value="Check Out"/> 
<!--when clicked, sends all datas to formtest.php -->
<input id="reset" type="reset" value="Cancel Order"/> 
<!--when clicked, resets data and sends user to homepage using javascript-->
</p>


</form>



</section>


</article>



<?php
	include_once("footer.inc");
?>

</body>
</html>	
