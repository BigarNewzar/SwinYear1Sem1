<!DOCTYPE html>
<html lang="en">
<?php
	include_once("header.inc");
?>


<body>

<?php
	include_once("menu.inc");
?>



<aside id="right"> <!--put advert here to right of page-->
	<figure>

		<a href="https://www.primevideo.com/region/eu" >
			<img class="img" src="images/stream.png" alt="amazon stream advert"/>
		</a>

		<p>
			<a href="  https://www.pinterest.com/pin/561964859746504753/"> pic reference </a>
		</p>
	<!-- advert 1 src = https://www.pinterest.com/pin/561964859746504753/-->

	</figure>
</aside>


<article>

<h1 id="bring_down"> Some information about me:</h1>

<section class="into_stuff">



<aside ><figure >
	<img  id="selfpic" src = "images/pic.jpeg" alt="a picture of S M Ragib Rezwan"/>
	
	
</figure>
</aside>
</section>

<section class="my_details">
<!--need to use defn list here!!-->
<dl>
	<dt>Name:</dt>
	<dd>S M Ragib Rezwan</dd>
	<dt>Student ID:</dt>
	<dd>s103172423</dd>
	<dt>Course:</dt>
	<dd>Bachelor of Computer Science</dd>
	<dt>Email:</dt>
	<dd><a href="mailto:103172423@student.swin.edu.au" >103172423@student.swin.edu.au</a></dd>
</dl>
</section>
 
<section class="my_details">


<table id="swinburne">
<caption> My Swinburne Timetable</caption>
<thead>
	<tr>
		<th>Starting Time (in Australia)</th>
		<th>Sunday</th>
		<th>Monday</th>
		<th>Tuesday</th>
		<th>Wednesday</th>
		<th>Thursday</th>
		<th>Friday</th>
		<th>Saturday</th>
	</tr>
</thead>
<tbody>
	<tr>
		<th>8:00 AM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>8:30 AM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td rowspan="4" class="cos10009"> COS10009 Lab 2 or Workshop 2</td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>9:00 AM</th>
		
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>9:30 AM</th>
		
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>10:00 AM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
		<td rowspan="4" class="cos10009">COS10009 Live Online 1</td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>10:30 AM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	
		<td rowspan="4" class="cos10009">COS10009 Workshop 2</td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>11:00 AM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>

	</tr>
	
	<tr>
		<th>11:30 AM</th>
		<td>&nbsp; </td>
		<td rowspan="4" class="cos10011">COS10011 Live Online 1</td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	
		<td rowspan="6" class="tne10005">TNE10005 Live Online 1</td>
	</tr>
	
	<tr>
		<th>12:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>12:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
		<td rowspan="4" class="cos10009">COS10009 Lab 1 (help desk)</td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>1:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	
		<td rowspan="4" class="cos10003">COS10003 Live Online 1</td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>1:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	
	
	<tr>
		<th>2:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>2:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td rowspan="2" class="cos10011">COS10011 Lab 1</td>
		
		<td rowspan="4" class="cos10003">COS10003 Tutorial Online 1</td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	
	</tr>
	
	<tr>
		<th>3:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>3:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>4:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	
	<tr>
		<th>4:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>5:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>5:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>6:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>6:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td rowspan="4" class="tne10005">TNE10005 Live Online 1</td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
	<tr>
		<th>7:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	
	</tr>
	
	<tr>
		<th>7:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	
	</tr>
	
	<tr>
		<th>8:00 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		
	</tr>
	<tr>
		<th>8:30 PM</th>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
		<td>&nbsp; </td>
	</tr>
	
</tbody>
<tfoot></tfoot>
</table>



</section>

<section class="my_details"> 
<p> Hi, I am Ragib. </p>
<p>
Have you ever thought of a person who would study day in and out?
<br/>
Someone who will do everything to make sure he masters a topic?
<br/>
Someone who will even sacrifice his own wellbeing to do so?
</p>
<p>Well that's me. Nice to meet you!</p>

<p>My hobbies include: </p>
<ul>
<li> Reading story books</li>
<li> Playing (or more like constantly losing) in Chess</li>
<li>Watching anime and tv shows</li>
<li>Listening to music</li>
<li>Sleeping</li>
</ul>

</section>



</article>





<?php
	include_once("footer.inc");
?>
</html>	
